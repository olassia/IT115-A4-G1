<?php include('includes/header.php');?>
    <div class="wrapper">
        
        <main>
            <h1>Doomsday prepper's Thanksgiving dinner</h1>
            <p>Hello, little man. I will destroy you!
We don't have a brig. Is that a cooking show? Wow! A superpowers drug you can just rub onto your skin? You'd think it would be something you'd have to freebase. Ummm…to eBay?

You, minion. Lift my arm. AFTER HIM! I guess because my parents keep telling me to be more ladylike. As though! Yes. You gave me a dollar and some candy. But I've never been to the moon! So, how 'bout them Knicks?

You, a bobsleder!? That I'd like to see!
You're going back for the Countess, aren't you? We're also Santa Claus! Fetal stemcells, aren't those controversial? You've killed me! Oh, you've killed me! Bender, this is Fry's decision… and he made it wrong. So it's time for us to interfere in his life.

Belligerent and numerous.
I saw you with those two "ladies of the evening" at Elzars. Explain that.
I haven't felt much of anything since my guinea pig died.</p>
        </main>

        <aside>
                <div class = "randomGif">
                    <img src="images/turk<?php $random = rand(1,8); echo $random; ?>.gif" alt="[]" height="100%" width="100%" />
                </div>
        </aside>
    </div>
    <?php include('includes/footer.html');?>

