<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>GitHub web page</title>
<link href="<?php echo $style ?>" type="text/css" rel="stylesheet">
<link href="style.css" type="text/css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500&family=Staatliches&display=swap" rel="stylesheet">
</head>

<body>
    <header>
        <div class="row">
            <h1>TURKEY DOOMSDAY</h1>
        </div>
    </header>
    <nav>
        <!--navigational list items-->
        <a href="index.php">Home</a>
        <a href="blahblah.php">Some page</a>
        <a href="about.php">About us</a>
        <a href="project.php">Project details</a>
    </nav>